package com.example.donorsmanagementsystem.controller;

import com.example.donorsmanagementsystem.entity.DonationRecord;
import com.example.donorsmanagementsystem.repository.DonationRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/records")
public class DonationRecordController {

    @Autowired
    private DonationRecordRepository donationRecordRepository;

    @PostMapping
    public DonationRecord createRecord(@RequestBody DonationRecord record) {
        return donationRecordRepository.save(record);
    }

    @GetMapping("/donor/{donorId}")
    public List<DonationRecord> getByDonor(@PathVariable Long donorId) {
        return donationRecordRepository.findByDonorId(donorId);
    }
}