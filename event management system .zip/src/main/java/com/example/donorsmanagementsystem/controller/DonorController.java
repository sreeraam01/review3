package com.example.donorsmanagementsystem.controller;

import com.example.donorsmanagementsystem.entity.Donor;
import com.example.donorsmanagementsystem.repository.DonorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/donors")
public class DonorController {

    @Autowired
    private DonorRepository donorRepository;

    @PostMapping
    public Donor createDonor(@RequestBody Donor donor) {
        return donorRepository.save(donor);
    }

    @GetMapping("/{id}")
    public Donor getDonor(@PathVariable Long id) {
        return donorRepository.findById(id).orElse(null);
    }

    @GetMapping
    public List<Donor> getAllDonors(@RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "5") int size) {
        return donorRepository.findAllByOrderByAgeAsc(PageRequest.of(page, size)).getContent();
    }

    @PutMapping("/{id}")
    public Donor updateDonor(@PathVariable Long id, @RequestBody Donor updatedDonor) {
        return donorRepository.findById(id).map(donor -> {
            donor.setName(updatedDonor.getName());
            donor.setAge(updatedDonor.getAge());
            donor.setBloodGroup(updatedDonor.getBloodGroup());
            return donorRepository.save(donor);
        }).orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteDonor(@PathVariable Long id) {
        donorRepository.deleteById(id);
    }

    @GetMapping("/blood-group/{group}")
    public List<Donor> getByBloodGroup(@PathVariable String group) {
        return donorRepository.findByBloodGroup(group);
    }
}