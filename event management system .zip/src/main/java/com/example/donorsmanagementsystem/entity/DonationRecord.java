package com.example.donorsmanagementsystem.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class DonationRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDate donationDate;
    private String location;

    @ManyToOne
    @JoinColumn(name = "donor_id")
    private Donor donor;

    // Getters and Setters
}