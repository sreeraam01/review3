package com.example.donorsmanagementsystem.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Donor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String bloodGroup;
    private int age;

    @OneToMany(mappedBy = "donor", cascade = CascadeType.ALL)
    private List<DonationRecord> donationRecords;

    // Getters and Setters
}