package com.example.donorsmanagementsystem.repository;

import com.example.donorsmanagementsystem.entity.DonationRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DonationRecordRepository extends JpaRepository<DonationRecord, Long> {
    List<DonationRecord> findByDonorId(Long donorId);
}