package com.example.donorsmanagementsystem.repository;

import com.example.donorsmanagementsystem.entity.Donor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface DonorRepository extends JpaRepository<Donor, Long> {
    @Query("SELECT d FROM Donor d WHERE d.bloodGroup = :bloodGroup")
    List<Donor> findByBloodGroup(String bloodGroup);

    Page<Donor> findAllByOrderByAgeAsc(Pageable pageable);
}